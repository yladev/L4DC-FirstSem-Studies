Create table Customers
(
	CustomerID Varchar(30) not null,
	CustomerName Varchar(30),
	CustomerPhone Varchar(30),
	CustomerEmail Varchar(30),
	CustomerAddress Varchar(30),
	Primary Key(CustomerID),
);
select * from Customers;

Insert into Customers(CustomerID, CustomerName, CustomerPhone, CustomerEmail, CustomerAddress)
Values('C-001', 'Jason', '09-757561263', 'jason@gmail.com', 'Yangon')
Insert into Customers(CustomerID, CustomerName, CustomerPhone, CustomerEmail, CustomerAddress)
Values('C-002', 'Steve', '09-784428522', 'steve@gmail.com', 'Mandalay')
Insert into Customers(CustomerID, CustomerName, CustomerPhone, CustomerEmail, CustomerAddress)
Values('C-003', 'Jame', '09-254488150', 'jame@gmail.com', 'Bago')

Create table Orders
(
	OrderID Varchar(30) Not Null,
	OrderDate Date,
	CustomerID Varchar(30) Not Null,
	Primary Key(OrderID),
	Foreign Key(CustomerID) references Customers(CustomerID),
);
select * from Orders;

Insert into Orders(OrderID, OrderDate, CustomerID)
Values('O-001', '9/9/2023', 'C-001')
Insert into Orders(OrderID, OrderDate, CustomerID)
Values('O-002', '8/8/2023', 'C-002')
Insert into Orders(OrderID, OrderDate, CustomerID)
Values('O-003', '7/7/2023', 'C-003')

Create table OrdersDetail
(
	OrderID Varchar(30) Not Null,
	OrderDate Date,
	ProductID Varchar(30) Not Null,
	OrderQuantity Int,
	Foreign Key(OrderID) references Orders(OrderID),
	Foreign Key(ProductID) references Products(ProductID),
);
select * from OrdersDetail;

Insert into OrdersDetail(OrderID, OrderDate, ProductID, OrderQuantity)
Values('O-001', '9/9/2023', 'P-001', 3)
Insert into OrdersDetail(OrderID, OrderDate, ProductID, OrderQuantity)
Values('O-002', '8/8/2023', 'P-002', 5)
Insert into OrdersDetail(OrderID, OrderDate, ProductID, OrderQuantity)
Values('O-003', '7/7/2023', 'P-003', 9)

Create table Products
(
	ProductID Varchar(30) Not Null,
	ProductName Varchar(30),
	ProductPrice Varchar(30),
	Primary Key(ProductID),
);
select * from Products;

Insert into Products(ProductID, ProductName, ProductPrice)
Values('P-001', 'Shirt', '$65')
Insert into Products(ProductID, ProductName, ProductPrice)
Values('P-002', 'Shoe', '$1000')
Insert into Products(ProductID, ProductName, ProductPrice)
Values('P-003', 'Hoodie', '$100')

Create table PurchaseDetail
(
	PurchaseID Varchar(30) Not Null,
	PurchaseDate Varchar(30),
	ProductID Varchar(30) Not Null,
	Foreign Key(PurchaseID) references Purchase(PurchaseID),
	Foreign Key(ProductID) references Products(ProductID),
);
select * from PurchaseDetail;

Insert into PurchaseDetail(PurchaseID, PurchaseDate, ProductID)
Values('Pur-001', '1/1/2023', 'P-001')
Insert into PurchaseDetail(PurchaseID, PurchaseDate, ProductID)
Values('Pur-002', '2/2/2023', 'P-002')
Insert into PurchaseDetail(PurchaseID, PurchaseDate, ProductID)
Values('Pur-003', '3/3/2023', 'P-003')

Create table Purchase
(
	PurchaseID Varchar(30) Not Null,
	SupplierID Varchar(30) Not Null,
	PurchaseDate Varchar(30),
	PurchaseQuantity Varchar(30),
	ProductPrice Varchar(30),
	Primary Key(PurchaseID),
	Foreign Key(SupplierID) references Suppliers(SupplierID),
);
select * from Purchase;

Insert into Purchase(PurchaseID, SupplierID, PurchaseDate, PurchaseQuantity, ProductPrice)
Values('Pur-001', 'S-001', '1/1/2023', '15', '$65')
Insert into Purchase(PurchaseID, SupplierID, PurchaseDate, PurchaseQuantity, ProductPrice)
Values('Pur-002', 'S-002', '2/2/2023', '20', '$1000')
Insert into Purchase(PurchaseID, SupplierID, PurchaseDate, PurchaseQuantity, ProductPrice)
Values('Pur-003', 'S-003', '3/3/2023', '25', '$100')

Create table Suppliers
(
	SupplierID Varchar(30) Not Null,
	SupplierName Varchar(30),
	SupplierAddress Varchar(30),
	SupplierEmail Varchar(30),
	SupplierPhone Varchar(30),
	Primary Key(SupplierID),
);
select * from Suppliers;

Insert into Suppliers(SupplierID, SupplierName, SupplierAddress, SupplierEmail, SupplierPhone)
Values('S-001', 'Sweety', 'England', 'sweety@gmail.com', '09-444458799')
Insert into Suppliers(SupplierID, SupplierName, SupplierAddress, SupplierEmail, SupplierPhone)
Values('S-002', 'Emily', 'America', 'emily@gmail.com', '09-451111468')
Insert into Suppliers(SupplierID, SupplierName, SupplierAddress, SupplierEmail, SupplierPhone)
Values('S-003', 'Joisy', 'Italy', 'joisy@gmail.com', '09-400494422')

select	o.OrderDate as [Date],
		c.CustomerName as [Customer Name],
		p.ProductName as [Products Name],
		p.ProductPrice as [Price],
		od.OrderQuantity as [Quantity]
from customers c, orders o, ordersdetail od, products p
where c.CustomerID=o.CustomerID and o.OrderID = od.OrderID and p.ProductID=od.ProductID

select	p.PurchaseDate as [Date],
		s.SupplierName as [Supplier Name],
		pt.ProductName as [Products Name],
		count(pd.ProductID) as [Quantity]
from suppliers s, Purchase p,PurchaseDetail pd,Products pt
where s.SupplierID=p.SupplierID and p.PurchaseID=pd.PurchaseID and pt.ProductID=pd.ProductID
group by p.PurchaseDate, s.SupplierName, pt.ProductName, pd.ProductID

select  o.OrderDate as [Order Date],
		p.ProductID as  [Products ID],
		p.ProductName as[Product Name],
		p.ProductPrice as  [Price]
from orders o, OrdersDetail od, Products p
where o.OrderID=od.OrderID and p.ProductID=od.ProductID

Update Customers
Set CustomerEmail = 'jason02@gmail.com'
Where CustomerID = 'C-001';
select * from Customers Where CustomerID = '001';